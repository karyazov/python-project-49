### Hexlet tests and linter status:
[![Actions Status](https://github.com/karyazov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/karyazov/python-project-49/actions)

### CodeClimate badge
https://codeclimate.com/github/karyazov/python-project-49/maintainability

### ASCIINEMA
### STEP 5
https://asciinema.org/a/Sjk9JCs2Q3wnKryfrWTiyk54y

### STEP6
https://asciinema.org/a/a0wHXYESHSKz30vWAKizHbhYF

### STEP 7
https://asciinema.org/a/7xveD7h6NlvKnnhkrlys0UcUr

### STEP 8
https://asciinema.org/a/I9g0qBtTgQswPp2F2mbtv817D

### STEP 9
https://asciinema.org/a/0jK6U4pE3eSBPv9qjTA9kGcbf
