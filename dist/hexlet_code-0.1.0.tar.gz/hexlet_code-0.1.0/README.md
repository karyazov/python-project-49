### Hexlet tests and linter status:
[![Actions Status](https://github.com/karyazov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/karyazov/python-project-49/actions)

### CodeClimate badge
https://codeclimate.com/github/karyazov/python-project-49/maintainability

### ASCIINEMA
### STEP 5
https://asciinema.org/a/Sjk9JCs2Q3wnKryfrWTiyk54y

### STEP6
https://asciinema.org/connect/f7bf5754-f9d3-49b1-8aed-2effea953c41